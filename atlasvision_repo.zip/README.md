# AtlasVision

**AI Shop Inventory Scanner & Real-Time Insight Engine**

Turn shelf photos and short videos into structured inventory, low-stock alerts, price comparisons and actionable restock recommendations.

---

## Table of contents
1. Project Overview
2. Core Features
3. Architecture & System Design (diagrams)
4. HuggingFace Models & Inference
5. Tech Stack
6. API Design & Endpoints
7. Database SQL Schema
8. Local Dev Setup
9. Deployment (Docker + Docker Compose)
10. Scaffolding: Backend (FastAPI) - code files
11. How to demo & portfolio tips
12. Roadmap & Future Work

---

## 1. Project Overview
AtlasVision converts smartphone shelf images into structured inventory data. It combines OCR, image classification and VQA to extract product names, estimate stock levels, detect missing items, and enrich results with price and supplier metadata from real-world APIs.

**Primary users:** small-shop owners, micro-distributors, inventory managers in under-digitized retail environments.

**Goals:**
- Demonstrate strong systems and ML integration skills.
- Deliver an end-to-end pipeline: mobile capture → async processing → analytics dashboard.
- Use real external APIs to show business value.

---

## 2. Core Features
- Upload shelf images or short videos
- OCR extraction of product labels & SKUs
- Product category classification and count/stock estimate
- Visual QA for queries like "missing items?" or "how many X?"
- Enrichment via price comparison APIs (e.g., Jumia, Carrefour, OpenFoodFacts)
- Low-stock alerts (push/WhatsApp/Email)
- Dashboard for analytics & trends

---

## 3. Architecture & System Design

High-level flow:

```
[Mobile App / Web UI] -> [Object Storage (S3 or Supabase Storage)] -> [FastAPI Gateway]
-> [Redis Queue / Celery] -> [Worker Pipeline -> HF Inference] -> [Normalization & Enrichment]
-> [Postgres (Supabase)] -> [Insights Engine] -> [Notifications + Dashboard]
```

Component responsibilities are described in the repo `docs/` and inside `backend/` code comments.

---

## 4. HuggingFace Models & Inference
Primary tasks and suggested models:
- OCR (image-to-text): `deepseek-ai/DeepSeek-OCR` or `microsoft/trocr-base-printed`
- Image Classification: `google/vit-base-patch16-224`
- VQA (Visual Question Answering): `Salesforce/blip-vqa-base` or `microsoft/vilt-b32-finetuned-vqa`

Use the HF Inference API for quick prototyping (HF API token required).

---

## 5. Tech Stack
- Backend: FastAPI, Python 3.11
- Workers: Celery + Redis
- ORM: SQLModel (or SQLAlchemy) with PostgreSQL (Supabase)
- Storage: AWS S3 or Supabase Storage for images
- HF: HuggingFace Inference API
- Mobile: Flutter (recommended) or React/Next.js
- Deployment: Docker, Docker Compose

---

## 6. API Design & Endpoints
- `POST /auth/signup` — create shop/user
- `POST /auth/login` — returns JWT
- `POST /api/v1/scan` — upload image → returns `scan_id` (processing)
- `GET /api/v1/scan/{scan_id}` — get processing status & results
- `GET /api/v1/shop/{shop_id}/inventory` — get current inventory JSON
- `GET /api/v1/shop/{shop_id}/analytics` — get aggregated insights
- `POST /api/v1/alerts` — configure alert thresholds

---

## 7. Database SQL Schema
See `backend/sql/schema.sql`

---

## 8. Local Dev Setup (Quick)
1. Clone the repo
2. Copy `.env.example` to `.env` and fill variables (DATABASE_URL, HF_API_KEY, S3 creds, REDIS_URL)
3. `docker-compose up --build`
4. `curl -X POST 'http://localhost:8000/api/v1/scan' -F 'image=@demo_images/sample_shelf.png' -H 'Authorization: Bearer <token>'`

---

## 9. Deployment
A `docker-compose.yml` is included for local development: services `web` (FastAPI), `worker` (Celery), `redis`, `db` (Postgres).

---

## 10. Scaffolding: Backend (FastAPI)
See `backend/app/` for a runnable scaffold. Core files include:
- `main.py` (FastAPI app)
- `db.py` (DB init and session)
- `models.py` (SQLModel models)
- `hf_client.py` (HuggingFace inference helpers)
- `tasks.py` (Celery worker: `process_scan`)
- `requirements.txt`

---

## 11. How to demo & portfolio tips
- Create a 90s demo video showing mobile capture → processing → dashboard insights → reorder flow with price comparison.
- Include a public GitHub repo with README, docker-compose, and a small demo dataset in `/demo_images`.

---

## 12. Roadmap & Future Work
- Fine-tune classification/OCR models on localized product images
- Implement barcode detection & GTIN linking
- Add predictive restock ML model (time-series)
- Integrate supplier ordering
- Add multi-shop analytics & RBAC

---


# Flutter Demo Scaffold for AtlasVision

This folder contains a minimal structure and instructions for a Flutter app that captures or selects an image and uploads it to the backend.

Files here are placeholders. To build the Flutter app clone the repository and follow the README in this folder.

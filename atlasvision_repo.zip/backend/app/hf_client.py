import os
import requests

HF_API_URL = 'https://api-inference.huggingface.co/models'
HF_TOKEN = os.getenv('HF_API_TOKEN')

HEADERS = {'Authorization': f'Bearer {HF_TOKEN}'} if HF_TOKEN else {}

def call_hf_model(model_name: str, inputs, content_type='application/json'):
    url = f"{HF_API_URL}/{model_name}"
    if isinstance(inputs, (bytes, bytearray)):
        headers = HEADERS.copy()
        headers['Content-Type'] = 'application/octet-stream'
        resp = requests.post(url, headers=headers, data=inputs, timeout=120)
    else:
        resp = requests.post(url, headers=HEADERS, json={'inputs': inputs}, timeout=120)
    resp.raise_for_status()
    return resp.json()

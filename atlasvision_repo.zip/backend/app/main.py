from fastapi import FastAPI, UploadFile, File, HTTPException
from app.db import init_db, engine
from app.models import Scan
from sqlmodel import Session
import uuid, os

init_db()
app = FastAPI(title='AtlasVision')

@app.post('/api/v1/scan')
async def upload_scan(shop_id: str, file: UploadFile = File(...)):
    # store file to local tmp storage for quick dev
    tmp_dir = '/mnt/data/atlasvision_tmp'
    os.makedirs(tmp_dir, exist_ok=True)
    filename = f\"{uuid.uuid4()}_{file.filename}\"
    filepath = os.path.join(tmp_dir, filename)
    contents = await file.read()
    with open(filepath, 'wb') as f:
        f.write(contents)

    image_url = 'file://' + filepath

    scan = Scan(shop_id=shop_id, image_url=image_url)
    with Session(engine) as session:
        session.add(scan)
        session.commit()
        session.refresh(scan)
        # enqueue worker
        try:
            from app.tasks import process_scan
            process_scan.delay(str(scan.id))
        except Exception as e:
            # if celery not running, process inline for demo
            from app.tasks import process_scan as proc
            proc(str(scan.id))

    return {'scan_id': str(scan.id), 'status': 'processing'}

@app.get('/api/v1/scan/{scan_id}')
def get_scan(scan_id: str):
    with Session(engine) as session:
        scan = session.get(Scan, scan_id)
        if not scan:
            raise HTTPException(status_code=404, detail='scan not found')
        return {'id': scan.id, 'status': scan.status, 'normalized': scan.normalized}

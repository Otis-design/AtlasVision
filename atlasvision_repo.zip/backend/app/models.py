from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime

class Shop(SQLModel, table=True):
    id: Optional[str] = Field(default=None, primary_key=True)
    name: str
    owner_email: Optional[str]
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Scan(SQLModel, table=True):
    id: Optional[str] = Field(default=None, primary_key=True)
    shop_id: str
    image_url: str
    status: str = 'pending'
    meta: Optional[dict] = None
    normalized: Optional[dict] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Product(SQLModel, table=True):
    id: Optional[str] = Field(default=None, primary_key=True)
    shop_id: str
    name: Optional[str]
    sku: Optional[str]
    category: Optional[str]
    quantity: int = 0
    last_seen: Optional[datetime] = None
    price: Optional[float] = None
    external_meta: Optional[dict] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

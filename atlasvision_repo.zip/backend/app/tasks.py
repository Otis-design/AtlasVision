import os
from celery import Celery
from app.hf_client import call_hf_model
from app.db import engine
from sqlmodel import Session, select
from app.models import Scan, Product
from datetime import datetime

CELERY_BROKER = os.getenv('CELERY_BROKER_URL', 'redis://redis:6379/0')
CELERY_BACKEND = os.getenv('CELERY_RESULT_BACKEND', 'redis://redis:6379/1')
celery = Celery('tasks', broker=CELERY_BROKER, backend=CELERY_BACKEND)

OCR_MODEL = 'deepseek-ai/DeepSeek-OCR'
VQA_MODEL = 'Salesforce/blip-vqa-base'
CLASS_MODEL = 'google/vit-base-patch16-224'

@celery.task()
def process_scan(scan_id: str):
    with Session(engine) as session:
        scan = session.get(Scan, scan_id)
        if not scan:
            return
        scan.status = 'processing'
        session.add(scan)
        session.commit()

        # fetch image bytes (supports file:// local path or http(s) url)
        import requests
        img_url = scan.image_url
        if img_url.startswith('file://'):
            path = img_url.replace('file://', '')
            with open(path, 'rb') as f:
                img_bytes = f.read()
        else:
            img_bytes = requests.get(img_url).content

        # OCR
        try:
            ocr_result = call_hf_model(OCR_MODEL, img_bytes)
        except Exception as e:
            scan.status = 'failed'
            scan.meta = {'error': str(e)}
            session.add(scan)
            session.commit()
            return

        # Classification (simplified):
        try:
            class_result = call_hf_model(CLASS_MODEL, img_bytes)
        except Exception as e:
            class_result = {'error': str(e)}

        # VQA example question
        try:
            # some HF VQA models expect multipart with image and question; simplified here
            vqa_result = call_hf_model(VQA_MODEL, {'image': '<image_bytes_placeholder>', 'question': 'Which items are missing?'})
        except Exception as e:
            vqa_result = {'error': str(e)}

        normalized = {
            'ocr': ocr_result,
            'classes': class_result,
            'vqa': vqa_result
        }

        scan.normalized = normalized
        scan.status = 'done'
        session.add(scan)
        session.commit()

        # Basic upsert into products (naive example)
        detected_names = []
        if isinstance(ocr_result, list):
            detected_names = [x.get('word', x) if isinstance(x, dict) else x for x in ocr_result]
        elif isinstance(ocr_result, dict):
            # try to find text keys
            text = ocr_result.get('text') or ocr_result.get('words') or ''
            if isinstance(text, str):
                detected_names = [t.strip() for t in text.splitlines() if t.strip()]

        for name in detected_names:
            # naive matching
            statement = select(Product).where(Product.shop_id==scan.shop_id, Product.name==name)
            existing = session.exec(statement).first()
            if existing:
                existing.quantity = existing.quantity + 1
                existing.last_seen = datetime.utcnow()
                session.add(existing)
            else:
                p = Product(shop_id=scan.shop_id, name=name, quantity=1, last_seen=datetime.utcnow())
                session.add(p)
        session.commit()

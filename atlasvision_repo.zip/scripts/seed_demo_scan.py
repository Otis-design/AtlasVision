#!/usr/bin/env python3
import requests
import os, time

API_URL = os.getenv('ATLASVISION_API', 'http://localhost:8000')
SHOP_ID = 'demo-shop-0001'

def upload_sample():
    path = os.path.join('demo_images', 'sample_shelf.png')
    files = {'file': open(path, 'rb')}
    resp = requests.post(f"{API_URL}/api/v1/scan?shop_id={SHOP_ID}", files=files)
    print('upload response', resp.status_code, resp.text)
    if resp.ok:
        scan_id = resp.json().get('scan_id')
        for i in range(10):
            r = requests.get(f"{API_URL}/api/v1/scan/{scan_id}")
            print('status', r.status_code, r.text)
            if r.ok and r.json().get('status') == 'done':
                break
            time.sleep(2)

if __name__ == '__main__':
    upload_sample()
